Instruções:

1. Conte a quantidade de pixels verdes.
2. A imagem possui uma mensagem escondida, descubra qual a mensagem.
